import 'package:flutter/material.dart';

class Kalkulator extends StatefulWidget {
  const Kalkulator({super.key});

  @override
  State<Kalkulator> createState() => _KalkulatorState();
}

class _KalkulatorState extends State<Kalkulator> {
  String cals = '0';
  String cals2 = '';
  int hitung1 = 0;
  int hitung2 = 0;
  String operatorMat = '';

  void hitungCal(int v) {
    setState(() {
      if (cals != '0') {
        cals = '$cals$v';
      } else {
        cals = '$v';
      }

      if (operatorMat.isNotEmpty) {
        cals2 = '$cals2$v';
        hitung2 = int.parse(cals2);
      } else {
        hitung1 = int.parse(cals);
      }
    });
  }

  void tambahCal() {
    if (operatorMat.isEmpty) {
      operatorMat = '+';
      cals2 = '';
      setState(() {
        cals = '$cals+';
      });
    }
  }

  void kurangCal() {
    if (operatorMat.isEmpty) {
      operatorMat = '-';
      cals2 = '';
      setState(() {
        cals = '$cals-';
      });
    }
  }

  void kaliCal() {
    if (operatorMat.isEmpty) {
      operatorMat = '*';
      cals2 = '';
      setState(() {
        cals = '$cals*';
      });
    }
  }

  void bagiCal() {
    if (operatorMat.isEmpty) {
      operatorMat = '/';
      cals2 = '';
      setState(() {
        cals = '$cals/';
      });
    }
  }

  void hasilCal() {
    setState(() {
      switch (operatorMat) {
        case '+':
          hitung1 += hitung2;
          break;
        case '-':
          hitung1 -= hitung2;
          break;
        case '*':
          hitung1 *= hitung2;
          break;
        case '/':
          if (hitung2 != 0) {
            hitung1 ~/= hitung2;
          } else {
            hitung1 = 0;
          }
          break;
        default:
          break;
      }
      cals = '$hitung1';
      operatorMat = '';
      cals2 = '';
      hitung2 = 0;
    });
  }

  void clearCal() {
    setState(() {
      cals = '0';
      cals2 = '';
      hitung1 = 0;
      hitung2 = 0;
      operatorMat = '';
    });
  }

  Widget buildButton(String text, {Color color = Colors.blue}) {
    return Container(
      margin: const EdgeInsets.all(10),
      child: ElevatedButton(
        onPressed: () {
          switch (text) {
            case 'C':
              clearCal();
              break;
            case '+':
              tambahCal();
              break;
            case '-':
              kurangCal();
              break;
            case 'x':
              kaliCal();
              break;
            case '/':
              bagiCal();
              break;
            case '=':
              hasilCal();
              break;
            default:
              hitungCal(int.parse(text));
              break;
          }
        },
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          minimumSize: const Size(80, 80),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20.0),
          ),
          elevation: 5,
          textStyle: const TextStyle(fontSize: 24),
        ),
        child: Text(text),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Kalkulator'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            alignment: Alignment.centerRight,
            child: Text(
              cals,
              style: const TextStyle(
                fontSize: 60,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
          ),
          const SizedBox(height: 20),
          Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  buildButton('1'),
                  buildButton('2'),
                  buildButton('3'),
                  buildButton('+', color: Colors.orange),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  buildButton('4'),
                  buildButton('5'),
                  buildButton('6'),
                  buildButton('-', color: Colors.orange),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  buildButton('7'),
                  buildButton('8'),
                  buildButton('9'),
                  buildButton('x', color: Colors.orange),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  buildButton('C', color: Colors.red),
                  buildButton('0'),
                  buildButton('=', color: Colors.green),
                  buildButton('/', color: Colors.orange),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}
